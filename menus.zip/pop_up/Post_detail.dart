import 'package:byhands_application/theme.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class Post_DetailPage extends StatefulWidget {
  @override
  State<Post_DetailPage> createState() => _Post_DetailPageState();
  final String postName;

  const Post_DetailPage({super.key, required this.postName});
}

class _Post_DetailPageState extends State<Post_DetailPage> {
  final SupabaseClient supabase = Supabase.instance.client;

  String? imageUrl;
  // Initially, the image URL is null, waiting to be fetched.
  String? description;

  List<Map<String, dynamic>> details = [];

  @override
  void initState() {
    super.initState();
    fetchPost();
  }

  // Function to fetch the image URL asynchronously
  Future<void> fetchPost() async {
    final response = await supabase
        .from('Post')
        .select()
        .eq('Name', widget.postName)
        .maybeSingle();

    fetchPostDetails();

    if (response != null) {
      // Fetch the public URL for the image
      final imageUrlResponse = supabase.storage
          .from('images')
          .getPublicUrl('${response['Post_url']}');
      setState(() {
        imageUrl = imageUrlResponse; // Set the image URL once fetched
      });
    }
  }

  Future<void> fetchPostDetails() async {
    try {
      final response =
          await supabase.from('Post').select().eq('Name', widget.postName);

      setState(() {
        details = (response as List<dynamic>?)
                ?.map((e) => {
                      'Name': e['Name'] ?? 'Unknown', // Handle null values
                      'Content_Text': e['Content_Text'] ?? 'No content',
                      'category': e['category'] ?? 'No category',
                      'username': e['username'] ?? 'Not mentioned',
                      'Post_url': e['Post_url'] ?? 'No post url',
                    })
                .toList() ??
            [];
      });
    } catch (error) {
      print('Error fetching Courses: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
      ),
      body: imageUrl == null
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: <Widget>[
                  Column(
                    children: [
                      Center(
                        child: Text(
                          widget.postName,
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 26,
                              color: Color.fromARGB(255, 54, 43, 75)),
                        ),
                      ),
                      Center(
                        child: Image.network(
                          imageUrl!, // Display the image once the URL is fetched
                          width: 200,
                          height: 200,
                        ),
                      ),
                      SizedBox(
                        width: 20,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 5),
                            child: Container(
                              decoration: customContainerDecoration(context),
                              child: Row(
                                children: [
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Icon(
                                    Icons.message,
                                    color: Color.fromARGB(255, 54, 43, 75),
                                  ),
                                  TextButton(
                                    onPressed: () {},
                                    child: Text(
                                      "Contact provider",
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: Color.fromARGB(255, 54, 43, 75),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          IconButton(
                            color: Color.fromARGB(255, 54, 43, 75),
                            onPressed: () {},
                            icon: Icon(Icons.favorite),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
    );
  }
}
