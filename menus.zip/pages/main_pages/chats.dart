import 'package:byhands_application/menus/mainmenu.dart';
import 'package:flutter/material.dart';
import 'package:byhands_application/menus/side_menu.dart';

int index = 4;

class Chats extends StatelessWidget {
  const Chats({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).appBarTheme.backgroundColor,
        title: Text("Chats", style: Theme.of(context).textTheme.titleLarge),
        leading: Builder(
          builder: (BuildContext context) {
            return IconButton(
              icon: const Icon(Icons.menu),
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
            );
          },
        ),
      ),
      drawer: CommonDrawer(),
      bottomNavigationBar: mainMenu(index),
    );
  }
}
